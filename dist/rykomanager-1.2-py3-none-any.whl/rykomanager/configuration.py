#@TODO normalize path so escape characterdatabase_location
database_location = 'sqlite:///C:\\rykomanager\\rykomanager.db'
annex_docx = 'C:\\rykomanager\\mergefield_docs\\aneks_wzor.docx'
record_docx = 'C:\\rykomanager\\mergefield_docs\\wz.docx'
output_dir_main = 'C:\\rykomanager\\program_2018_2019_sem1'
output_dir_school = 'szkoly'
annex_folder_name = 'AneksyIumowy'
record_folder_name = 'WZ'
# libreoffice_converter = 'C:\\Program Files\\LibreOffice\\program\\soffice.exe'
libreoffice_converter = 'C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe'
current_program_id = 1
